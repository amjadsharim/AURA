
import json

def load_profile(path='user_profiles/blind_user_001.json'):
    with open(path, 'r') as f:
        return json.load(f)

def save_profile(profile, path='user_profiles/blind_user_001.json'):
    with open(path, 'w') as f:
        json.dump(profile, f, indent=4)

def adapt_profile(profile, replays, skips, duration):
    prefs = profile['preferences']
    if replays > skips:
        prefs['verbosity'] = 'detailed'
        prefs['speech_rate'] = 'slow'
    elif skips > replays:
        prefs['verbosity'] = 'brief'
        prefs['speech_rate'] = 'fast'
    return profile
