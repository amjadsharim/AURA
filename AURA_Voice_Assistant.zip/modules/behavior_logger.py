
import csv
from datetime import datetime

def log_behavior(replays, skips, duration, log_file='logs/interaction_log.csv'):
    with open(log_file, 'a') as file:
        writer = csv.writer(file)
        writer.writerow([datetime.now(), replays, skips, duration])
