
def build_prompt(user_input, profile):
    base = "You are a helpful assistant for blind users. "

    if profile['preferences']['verbosity'] == "brief":
        base += "Use short, direct answers. "
    else:
        base += "Provide comprehensive and detailed answers. "

    if profile['preferences']['speech_rate'] == "slow":
        base += "Speak slowly and clearly. "
    elif profile['preferences']['speech_rate'] == "fast":
        base += "Speak quickly and concisely. "

    return base + f'User said: "{user_input}"'
