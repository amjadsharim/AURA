
from modules.speech_input import get_user_input
from modules.speech_output import speak
from modules.behavior_logger import log_behavior
from modules.profile_manager import load_profile, save_profile, adapt_profile
from modules.prompt_generator import build_prompt
from modules.llm_interface import query_llm
import time

def main():
    profile = load_profile()
    while True:
        speak("Please say something.")
        user_input = get_user_input()
        if not user_input:
            speak("Sorry, I didn't catch that.")
            continue

        prompt = build_prompt(user_input, profile)
        response = query_llm(prompt)
        speak(response)

        # Simulated behavior tracking
        replays = 1
        skips = 0
        duration = 3.5
        log_behavior(replays, skips, duration)

        profile = adapt_profile(profile, replays, skips, duration)
        save_profile(profile)

        speak("Do you want to continue? Say yes or no.")
        if get_user_input().lower() == "no":
            break

if __name__ == "__main__":
    main()
